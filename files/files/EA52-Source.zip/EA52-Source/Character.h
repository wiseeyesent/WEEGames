/********************************************************************
//	Character.h
//	2012 12 14 - J. A. Cripe jacripe@gmail.com http://wiseeyesent.com
//
//	Character Class Header File
//	Includes:
//			- Class/Function Declarations
//			- Any Character Specific Includes
//
********************************************************************/
#ifndef __CHAR
#define __CHAR

#include "Graphics.h"

extern float timerRate;

extern bool cheater;

enum CHAR_TYPE {
	cPLAYER = 0,
	cENEMY = 1,
	cALLY = 2
};

#ifndef __OBJ_TYPE
#define __OBJ_TYPE
enum OBJ_TYPE {
	oWALL,
	oLDOOR,
	oUDOOR,
	oKEY,
	oENEMY,
	oALLY
};
#endif //__OBJ_TYPE

#ifndef __CHAR_DIR
#define __CHAR_DIR
enum CHAR_DIR {
	N = 0,
	E = 1,
	S = 2,
	W = 3,
};
#define NUM_DIRS 4
#endif //__CHAR_DIR

class Character {
public:
	int	id;	//Unique Character ID
	float	posX, // Position Data
			posY,
			defaultX, // Default Positions at the start of a map
			defaultY,
			velX, // Velocity Data
			velY;
	int		nKeys; // Number of Keys Held

	bool	mKey;

	bool	isStanding;

	CHAR_TYPE	charType;
	CHAR_DIR	dir;

	Sprite	sprite;

	std::ofstream	*log;

	Character*	prev;
	Character*	next;

public:
	Character(float x, float y, CHAR_TYPE c);
	
	void	setPos(float x, float y);
	void	getPos(float* x, float* y);
	void	setVel(float x, float y);
	void	getVel(float* x, float* y);

	void	pickupKey() { ++nKeys; }
	void	useKey() { --nKeys;}

	bool	standing(void);
	void	crouch(void);
	void	stand(void);
	void	toggleStanding(void) { if(isStanding) this->crouch(); else this->stand(); }
	void	move(void);
	void	resetPos(void) { posX = defaultX; posY = defaultY; }

	void	setSprite(Sprite s);
	Sprite	getSprite(void);
	void	cycleFrame(void);
	void	updateDir(void);

	void	setSourceRect(RECT r) { sprite.sourceRect = r; }
	RECT	getSourceRect(void) { return sprite.sourceRect; }

	bool	checkCollision(float x, float y, OBJ_TYPE obj);
};

#endif //__CHAR