/********************************************************************
//	CharacterList.h
//	2013 02 14 - J. A. Cripe jacripe@gmail.com http://wiseeyesent.com
//
//	CharacterList Class Header File
//	Includes:
//			- Class/Function Declarations
//			- Any Character Specific Includes
//
********************************************************************/
#ifndef __CHAR_LIS
#define __CHAR_LIS

#include "Character.h"

class CharacterList {
public:
	Character*	node;	//Current Selected Character in List
	int			idx,	//Index of Current Node in List
				cnt,	//Count of Total Nodes in List
				prior;	//Index of previously selected node

	CharacterList(void);
	CharacterList(Character* c);
	CharacterList(CharacterList* l);

	void		addChar(Character* c);
	void		insertChar(Character* c, int i);
	Character*	removeCurrentChar();
	Character*	removeCharAt(int i);

	Character*	curr(void);
	Character*	first(void);
	Character*	last(void);
	Character*	charAt(int);

	Character*	next(void);
	Character*	prev(void);
};

#endif //__CHAR_LIS