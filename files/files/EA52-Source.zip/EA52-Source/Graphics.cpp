/********************************************************************
//	Graphics.cpp
//	2012 12 06 - J. A. Cripe jacripe@gmail.com http://wiseeyesent.com
//
//	Graphics Library Source Code
//	Includes:
//			- Class/Function Definitions
//			- Any Graphics Specific Classes/Objects
//
********************************************************************/
#include "Graphics.h"

const char* printTime(void) {
	time_t now;
	time(&now);
	return ctime(&now);
}

//JC Disabled logging
bool initGraphicsLib( void ) {
	//JC Disabled GFX_LOG
	//if(GFX_LOG == NULL) // Log does not exist, Initialize
		//if(!initGFXLog()) // Initialize Log
			//return false; // Log Initialization Failed
		//;

	if(testGraphicsLib()) {
		//GFX_LOG << "Graphics::initGraphicsLib: " << printTime() << "\tGraphics Library Test:\tPASS!\n";
	} else {
		//GFX_LOG << "Graphics::initGraphicsLib: " << printTime() << "\tGraphics Library Test:\tFAIL!\n";
		return false;
	}

	return true; // Everything is good!
}

void shutdownGraphicsLib( void ) {
	closeGFXLog();
}

bool initGFXLog(const char* logFile) {
	logFile = logFile == NULL ? "logs\\Graphics.log" : logFile;
	GFX_LOG.open(logFile);
	if(GFX_LOG.is_open() && GFX_LOG.good()) {
		//GFX_LOG << "Graphics Log Initialized\n";
		//GFX_LOG.flush();
		return true;
	}
	return false;
}

void closeGFXLog( void ) {
	GFX_LOG << "Graphics Log Closed @ " << printTime();
	GFX_LOG.flush();
	GFX_LOG.close();
}

bool testGraphicsLib( void ) {
	struct Sprite s;
	RECT temp;
	temp.top = 0;
	temp.bottom = SPRITE_SIZE;
	temp.left = 0;
	temp.right = SPRITE_SIZE;
	s.sourceRect = temp;
	s.pX = s.pY = 0;
	s.vX = s.vY = 1;

	if(!testSprite(s))
		return false;
	createGFXBuff();
	if(GFX_BUFF == NULL)
		return false;
	return true;
}

// Test if Sprite was initialized (values contain data)
bool testSprite(struct Sprite s) {
	if(s.pX >= 0 && s.pX < SCREEN_WIDTH &&
	   s.pY >= 0 && s.pY < SCREEN_HEIGHT &&
	   s.vX >= 0 && s.vY >= 0)
	   return true;

	return false;
}

bool createGFXBuff(void) {
	//GFX_LOG << "Graphics::createGFXBuff @ " << printTime() << "createGraphicsBuff() START\n";
	GFX_BUFF = NULL;
	if(d3ddev == NULL) {
		//GFX_LOG << "Graphics::createGFXBuff @ " << printTime() << "\tERROR! Direct3DDevice is NULL!\n";
		return false;
	}

	HRESULT res;
	const char* sprites = "Art\\Sprites.png";

	//JC Added for Alpha Capable Sprites
	if(FAILED(D3DXCreateSprite(d3ddev, &AlphaSprite)))
		return false;
	D3DXCreateTextureFromFileEx(
		d3ddev,
		sprites,				// Our texture image!
		D3DX_DEFAULT,			// width
		D3DX_DEFAULT,			// height
		D3DX_DEFAULT,			// MIP levels
		0,						// usage
		D3DFMT_DXT1,			// texture format
		D3DPOOL_MANAGED,		// mem pool
		D3DX_DEFAULT,			// filter
		D3DX_DEFAULT,			// MIP filter
		0,						// transparent color key
		NULL,					// image info struct
		NULL,					// palette
		&AlphaTexture);			// the returned texture, if success

	res = d3ddev->CreateOffscreenPlainSurface(SCREEN_WIDTH, SCREEN_HEIGHT, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &GFX_BUFF, NULL);
	if( FAILED(res) ) {
		//GFX_LOG << "Graphics::createGFXBuff @ " << printTime() << "\tFailed to create GFX_BUFF, Result: " << res << "\n";
		return false;
	}

	D3DXIMAGE_INFO	sprite_info;
	res = D3DXGetImageInfoFromFile(sprites, &sprite_info);
	if( FAILED(res) ) {
		//GFX_LOG << "Graphics::createGFXBuff @ " << printTime() << "\tFailed to get image info from file: " << sprites << "\n"
		//	<< "\tResult: " << res << "\n";
		return false;
	}

	res = D3DXLoadSurfaceFromFile(GFX_BUFF, NULL, NULL, sprites, NULL, D3DX_DEFAULT, 0, &sprite_info);
	if( FAILED(res) ) {
		//GFX_LOG << "Graphics::createGFXBuff: " << printTime() << "\tGFX_BUFF Failed to load sprites from file: " << sprites << "\n"
		//	<< "\tResult: " << res << "\n";
		return false;
	}
	//GFX_LOG << "Graphics::createGFXBuff: " << printTime() << "\tInitialized Graphics Buffer with File: " << sprites << "\n";
	//GFX_LOG << "Graphics::createGFXBuff @ " << printTime() << "createGraphicsBuff() END\n";
	return true;
}