// Includes
#include <time.h>
#include "Character.h"
#include "Fmod Assets/fmod.h"
#include "Fmod Assets/fmod.hpp"
#include "Fmod Assets/fmod_errors.h"

// Bullet Struct
struct Bullet
{
	Sprite sprite;
	float posX;
	float posY;
	float speed;

	bool isActive;
	bool checkCollision(float x, float y, OBJ_TYPE obj);
	
	void setSourceRect(RECT r) { sprite.sourceRect = r; }
	RECT getSourceRect(void) { return sprite.sourceRect; }
};

class Turret
{
public:

	// Global Variables
	float posX;
	float posY;
	bool isActive;
	bool canFire;
	time_t lastFired;
	time_t currentTime;
	double secDif;
	int dir;
	Bullet bullet;

	//Constructer
	Turret();

	//Functions
	void updateBullets();
	void fire(FMOD::System*, FMOD::Sound*, FMOD::Channel*);
};