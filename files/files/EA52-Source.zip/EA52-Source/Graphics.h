/********************************************************************
//	Graphics.h
//	2012 12 06 - J. A. Cripe jacripe@gmail.com http://wiseeyesent.com
//
//	Graphics Library Header File
//	Includes:
//			- Class/Function Declarations
//			- Resource Paths
//			- Any Graphics Specific Includes
//
********************************************************************/
#ifndef __GFX_H
#define __GFX_H

//JC Moved here from ProjectIncludes.h
#ifndef __SCREEN_RES
#define __SCREEN_RES
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480
#define HUD_HEIGHT 50
#endif	//__SCREEN_RES

#define SPRITE_SIZE 20

extern const int ROWMAX;
extern const int COLMAX;

// Includes
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <time.h>
#include <vector>
#include <d3d9.h>
#include <D3dx9tex.h>

extern std::ofstream		LOG;
extern std::ofstream		GFX_LOG;
extern IDirect3DSurface9	*GFX_BUFF;
extern IDirect3DSurface9	*GFX_SPRITES;

//JC Added for Alpha Capable Sprites
extern ID3DXSprite			*AlphaSprite;
extern LPDIRECT3DTEXTURE9	AlphaTexture;

extern LPDIRECT3D9 d3d;
extern LPDIRECT3DDEVICE9 d3ddev;

const char* printTime(void);

// Data
struct Sprite {
	// Used for Sprite's Position in Sprite Sheet
	RECT sourceRect;

	// Position Data
	float pX;
	float pY;

	// Velocity Data
	float vX;
	float vY;

	int nFrames; // Number of frames
	int cFrame; // Current Frame Number
};

// Declarations
bool initGraphicsLib();
void shutdownGraphicsLib( void );
bool initGFXLog(const char* logFile = NULL);
void closeGFXLog();
bool testGraphicsLib();
bool testSprite(struct Sprite);
bool createGFXBuff(void);

//JC Moved from WinMain
// Map Specific Rendering
void renderMap(IDirect3DSurface9*);

//JC Character Rendering
void renderChars(IDirect3DSurface9*);

#endif //__GFX_H